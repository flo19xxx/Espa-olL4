AeroEspañol L4 v22 – GitHub Pages Struktur

WICHTIG:
Lade den INHALT dieses Ordners gemeinsam hoch. Nicht nur index.html.

Benötigte Struktur:
index.html
assets/
  photos/
    F01.png ... F20.png
  numbers/
    clear/
      0.ogg ... 1000.ogg
    radio/
      0.ogg ... 1000.ogg

GitHub Pages:
1. Neues Repository anlegen oder bestehendes öffnen.
2. index.html UND den gesamten Ordner assets hochladen.
3. Settings > Pages öffnen.
4. Deploy from a branch auswählen.
5. Branch main, Ordner /(root) auswählen.
6. Die von GitHub erzeugte HTTPS-Seite öffnen.

Warum diese Version stabiler ist:
- Fotos liegen als echte PNG-Dateien vor, nicht als Base64 in HTML.
- Jede Zahl besitzt eine eigene OGG-Datei. Dadurch gibt es kein Springen innerhalb einer langen Audiodatei und weniger abgeschnittene Wiedergabe in Edge.
- Spracherkennung akzeptiert ausgeschriebene spanische Zahlen, erkannte Ziffern und mehrere Recognition-Alternativen.
- Mikrofon/Spracherkennung sollte über die HTTPS-GitHub-Pages-Adresse verwendet werden.


Version v23: Zahlen 0–99 vollständig; ab 100 nur noch 10er-Schritte bis 1000. Nicht benötigte Audio-Dateien wurden entfernt.
